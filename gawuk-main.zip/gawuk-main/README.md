# gawuk
menjemur
